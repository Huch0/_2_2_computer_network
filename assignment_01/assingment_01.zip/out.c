#include <stdio.h>
#include <stdlib.h>

int main () {
    for (int i = 0; i < 5; i++) {
        int random = rand() % 100;
        printf("%d\n", random);

    }

    return 0;
}